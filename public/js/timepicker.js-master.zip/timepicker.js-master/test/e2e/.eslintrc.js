module.exports = {
  plugins: ['testcafe'],
  extends: ['plugin:testcafe/recommended'],
  rules: {
    'no-console': 0
  }
};
