module.exports = {
  extends: ['jwalker'],
  globals: {
    casper: true,
    patchRequire: true,
    phantom: true,
  },
  rules: {
    'no-console': 1,
  },
};
